<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>正在为您跳转到支付页面，请稍候...</title>
    <style type="text/css">
        body {margin:0;padding:0;}
        p {position:absolute;
            left:50%;top:50%;
            width:330px;height:30px;
            margin:-35px 0 0 -160px;
            padding:20px;font:bold 14px/30px "宋体", Arial;
            background:#f9fafc url(../assets/load.gif) no-repeat 20px 26px;
            text-indent:22px;border:1px solid #c5d0dc;}
        #waiting {font-family:Arial;}
    </style>
</head>
<body>
<?php
/* *
 * 功能：即时到账交易接口接入页
 * 
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

require_once("epay.config.php");
require_once("lib/epay_submit.class.php");

/**************************请求参数**************************/
		$url_base = strcasecmp($_SERVER['HTTPS'],"ON")==0?"https://":"http://";
		$url_base.= $_SERVER['HTTP_HOST'];
		$return_url = $url_base."/plugin/alipay/return_url.php";
		$notify_url = $url_base."/plugin/alipay/notify_url.php";

        //商户订单号
        $out_trade_no = $id;
        //商品名称
        $name = '在线充值';
		//付款金额
        $money = $money/100;
		//站点名称
        $sitename = 'VHMS';
        //必填
        //订单描述

/************************************************************/

//构造要请求的参数数组，无需改动
$parameter = array(
		"pid" => trim($alipay_config['partner']),
		"notify_url"	=> $notify_url,
		"return_url"	=> $return_url,
		"out_trade_no"	=> $out_trade_no,
		"name"	=> $name,
		"money"	=> $money,
		"sitename"	=> $sitename
);

//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestForm($parameter,'POST','正在跳转');
echo $html_text;

?>
<p>正在为您跳转到支付页面，请稍候...</p>
</body>
</html>