<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>即时到账支付</title>
</head>
<?php


$key='KEY';//您的key

$data['pid']='您的ID';

$data['type']=$_POST['type']; //wxpay qqpay alipay
$data['out_trade_no'] =  date("YmdHis").mt_rand(100,999);//您的单号
$data['money']='1.00'; //支付金额
$data['name']='123123'; //支付帐号

$data['notify_url'] = "http://".$_SERVER['HTTP_HOST']."/SDK/A/notify_url.php";
$data['return_url'] = "http://".$_SERVER['HTTP_HOST']."/SDK/A/return_url.php";
 
$data['sign']=md5($data['pid'].$data['money'].$data['type'].$data['name'].$data['notify_url'].$key);


$url= "http://codepay.lishi001.cn/submit.php";

$formItemString='';
foreach($data as $key=>$value){
    $formItemString.="<input name='{$key}' type='text' value='{$value}'/>";
}

$ok="
<form style='display:none' name='submit_form' id='submit_form' action='{$url}' method='post'>
{$formItemString}</form><script type='text/javascript'>document.submit_form.submit();</script>";
echo $ok;
exit;

?>
</body>
</html>