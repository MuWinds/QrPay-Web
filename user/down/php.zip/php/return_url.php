<!DOCTYPE HTML>
<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
//计算得出通知验证结果
   $key='KEY';
    $pid=$_GET['pid'];
    $out_trade_no=$_GET['out_trade_no'];
    $trade_no=$_GET['trade_no'];
    $endtime=$_GET['endtime'];
    $status=$_GET['status'];
    $money=$_GET['money'];
    $price=$_GET['price'];
    $tmoney=$_GET['tmoney'];
    $name=$_GET['name'];
    $type=$_GET['type'];
    $sign=$_GET['sign'];
     
    $sign2=md5($pid.$money.$type.$name.$tmoney.$key);
//echo $sign;
if($sign==$sign2) {//验证成功



    if($_GET['status'] == '1') {
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
    }
    else {
      echo "status=".$_GET['1'];
    }

	echo "验证成功<br />";

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    //如要调试，请看alipay_notify.php页面的verifyReturn函数
    echo "验证失败";
}
?>
        <title>即时到账交易接口</title>
	</head>
    <body>
    </body>
</html>