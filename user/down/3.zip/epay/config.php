<?php
return array(
	'plug' => 'epay',
	'name' => '开心码支付',
	'version' => '1.0',
);
?>