<?php
function epay_show()
{
    $configarray = array('plug' => 'epay', 'name' => '开心码支付', 'text' => '一站式免签约支付方案，提供支付宝、微信支付、QQ钱包codepay.lishi001.cn', 'icon' => 'alipay-icon');
    return $configarray;
}
function epay_config()
{
    $configarray = array("pid" => array("FriendlyName" => "商户ID", "Type" => "text", "Size" => "8","Description" => "申请商户请到codepay.lishi001.cn"), "key" => array("FriendlyName" => "商户密钥", "Type" => "text", "Size" => "32","Description" => "客服QQ2413123839"));
    return $configarray;
}
function epay_link($OSWAP_e33c6362689d6c573ea7bc36541a3eda, $OSWAP_9be41f914bd69144aae3c257cfdcd0ce)
{
    global $swap_mac;
	$OSWAP_2662881b5ec6cf8a6adf42d628fc6256['pid'] = plug_eva('epay', 'pid');
	$OSWAP_2662881b5ec6cf8a6adf42d628fc6256['key'] = plug_eva('epay', 'key');
	$OSWAP_2662881b5ec6cf8a6adf42d628fc6256['sign_type'] = strtoupper('MD5');
	$OSWAP_2662881b5ec6cf8a6adf42d628fc6256['input_charset'] = strtolower('utf-8');
	$OSWAP_2662881b5ec6cf8a6adf42d628fc6256['apiurl'] = 'http://codepay.lishi001.cn/';
	$OSWAP_43996c6055881617ab1a10c3dd4ce973 = 'http://';
	if ($_SERVER['HTTPS'] == "on") {
		$OSWAP_43996c6055881617ab1a10c3dd4ce973 = 'https://';
	}
	$OSWAP_9faefbbcac333fb27f909697771ede73 = $swap_mac['c']['网站名称'];

	requirer('lib/epay_core.function.php', 'epay');
	requirer('lib/epay_md5.function.php', 'epay');
	requirer('lib/epay_submit.class.php', 'epay');

	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['pid'] = trim($OSWAP_2662881b5ec6cf8a6adf42d628fc6256['pid']);
	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['notify_url'] = $OSWAP_43996c6055881617ab1a10c3dd4ce973 . $_SERVER['HTTP_HOST'] . "/index.php/pay/page/epay/notify/";
	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['return_url'] = $OSWAP_43996c6055881617ab1a10c3dd4ce973 . $_SERVER['HTTP_HOST'] . "/index.php/pay/page/epay/return/";
	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['out_trade_no'] = $OSWAP_9be41f914bd69144aae3c257cfdcd0ce;
	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['name'] = $OSWAP_9faefbbcac333fb27f909697771ede73 . '充值 #' . $OSWAP_9be41f914bd69144aae3c257cfdcd0ce;
	$OSWAP_98e57760c0002273d86b28deb5f4eb4ameter['money'] = $OSWAP_e33c6362689d6c573ea7bc36541a3eda;
    
	$OSWAP_6e50ab286503c1181bc6f57a3adf52c4 = new AlipaySubmit($OSWAP_2662881b5ec6cf8a6adf42d628fc6256);
	$OSWAP_07ed03f987b9a111422d3b6a9ce78390 = $OSWAP_6e50ab286503c1181bc6f57a3adf52c4->buildRequestForm($OSWAP_98e57760c0002273d86b28deb5f4eb4ameter, "POST", "正在跳转");
    return $OSWAP_07ed03f987b9a111422d3b6a9ce78390;
}